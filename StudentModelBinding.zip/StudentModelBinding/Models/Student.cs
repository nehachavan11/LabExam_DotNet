﻿
using Microsoft.Data.SqlClient;
namespace StudentModelBinding.Models

{
    public class Student
    {
        public int RollNo { get; set; }
        public string Name { get; set; }
        public string Stream { get; set; }
       
        public static List<Student> GetAllStudent()
        {
            List<Student> std = new List<Student>();
            SqlConnection cn = new SqlConnection();
            cn.ConnectionString = @"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=Assmnt2;Integrated Security=True";
            try
            {
                cn.Open();
                SqlCommand cmdInsert = new SqlCommand();
                cmdInsert.Connection = cn;
                cmdInsert.CommandType = System.Data.CommandType.Text;
                cmdInsert.CommandText = "select * from Students ";
                SqlDataReader dr = cmdInsert.ExecuteReader();
                while (dr.Read())
                    std.Add(new Student { RollNo = dr.GetInt32(0), Name = dr.GetString(1), Stream = dr.GetString(1) });
                dr.Close();
            }
            catch (Exception ex)
            {
                throw;
            }
            finally
            {
                cn.Close();
            }
            return std;
        }
        public static Student GetSingleStudent(int RollNo)
        {
            Student obj = new Student();
            SqlConnection cn = new SqlConnection();
            cn.ConnectionString = @"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=Assmnt2;Integrated Security=True";
            try
            {
                cn.Open();
                SqlCommand cmdInsert = new SqlCommand();
                cmdInsert.Connection = cn;
                cmdInsert.CommandType = System.Data.CommandType.Text;
                cmdInsert.CommandText = "select * from Students where RollNo=@RollNo";
                cmdInsert.Parameters.AddWithValue("@RollNo",RollNo);
                SqlDataReader dr = cmdInsert.ExecuteReader();
                if (dr.Read())
                {
                    obj.RollNo = dr.GetInt32(0);
                    obj.Name = dr.GetString(1);
                    obj.Stream = dr.GetString(2);
                   



                }
                else
                {
                    obj = null;
                    
                }
                dr.Close();



            }
            catch (Exception ex)
            {
                throw;
            }
            finally
            {
                cn.Close();
            }
            
            return obj;
        }
        public static void InsertStudent(Student obj)
        {
            SqlConnection cn = new SqlConnection();
            cn.ConnectionString = @"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=Assmnt2;Integrated Security=True";
            try
            {
                cn.Open();
                SqlCommand cmdInsert = new SqlCommand();
                cmdInsert.Connection = cn;
                cmdInsert.CommandType = System.Data.CommandType.Text;
                cmdInsert.CommandText = "insert into Students values(@RollNo,@Name,@Stream)";



                cmdInsert.Parameters.AddWithValue("@RollNo", obj.RollNo);
                cmdInsert.Parameters.AddWithValue("@Name", obj.Name);
                cmdInsert.Parameters.AddWithValue("@Stream", obj.Stream);
                
                cmdInsert.ExecuteNonQuery();

            }
            catch (Exception ex)
            {
                throw;
            }
            finally
            {
                cn.Close();
            }




        }


        public static void UpdateStudent(Student obj)
        {
            SqlConnection cn = new SqlConnection();
            cn.ConnectionString = @"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=Assmnt2;Integrated Security=True";
            try
            {
                cn.Open();
                SqlCommand cmdInsert = new SqlCommand();
                cmdInsert.Connection = cn;
                cmdInsert.CommandType = System.Data.CommandType.Text;
                cmdInsert.CommandText = "update Students set name=@Name, stream=@Stream where rolln =@RollNo";




                cmdInsert.Parameters.AddWithValue("@RollNo", obj.RollNo);
                cmdInsert.Parameters.AddWithValue("@Name", obj.Name);
                cmdInsert.Parameters.AddWithValue("@Stream", obj.Stream);
               
                cmdInsert.ExecuteNonQuery();



            }
            catch (Exception ex)
            {
                throw;
            }
            finally
            {
                cn.Close();
            }




        }
        public static void DeleteStudent(int RollNo)
        {
            SqlConnection cn = new SqlConnection();
            cn.ConnectionString = @"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=Assmnt2;Integrated Security=True";
            try
            {
                cn.Open();
                SqlCommand cmdInsert = new SqlCommand();
                cmdInsert.Connection = cn;
                cmdInsert.CommandType = System.Data.CommandType.Text;
                cmdInsert.CommandText = "delete from Students where rollno =@RollNo";

                cmdInsert.Parameters.AddWithValue("@RollNo", RollNo);
                cmdInsert.ExecuteNonQuery();

            }
            catch (Exception ex)
            {
                throw;
            }
            finally
            {
                cn.Close();
            }




        }
    }
}





