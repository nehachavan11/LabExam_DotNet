﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using StudentModelBinding.Models;

namespace StudentModelBinding.Controllers
{
    public class StudentsController : Controller
    {
        // GET: StudentController
        public ActionResult Index()
        {
            List<Student> std = Student.GetAllStudent();
            return View(std);
        }

        // GET: StudentController/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
                return NotFound();
            Student obj = Student.GetSingleStudent(id.Value);
            return View(obj);
        }
    

        // GET: StudentController/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: StudentController/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(Student obj)
        {
            try
            {
                Student.InsertStudent(obj);
                ViewBag.message = "Success!";
                return View();
                //return RedirectToAction(nameof(Index));
            }
            catch (Exception ex)
            {
                ViewBag.message = ex.Message;
                return View();
            }
        }

        // GET: StudentController/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
                return NotFound();
            Student obj = Student.GetSingleStudent(id.Value);
            return View(obj);
        }

        // POST: StudentController/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(int id, Student obj)
        {
            try
            {
                Student.InsertStudent(obj);
                ViewBag.message = "Success!";
                return View();
                
            }
            catch (Exception ex)
            {
                ViewBag.message = ex.Message;
                return View();
            }
        }

        // GET: StudentController/Delete/5
        public ActionResult Delete(int? id)
        {
             if (id == null)
                return NotFound();
            Student obj = Student.GetSingleStudent(id.Value);
            return View(obj);
        }

        // POST: StudentController/Delete/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Delete(int id, IFormCollection collection)
        {
            try
            {
                Student.DeleteStudent(id);
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }
    }
}
